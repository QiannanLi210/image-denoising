function x=nsst_rec1(dst,lpfilt,x_noisy)
% This function performs the inverse (local) nonsubsampled shearlet transform as given
% in G. Easley, D. Labate and W. Lim, "Sparse Directional Image Representations
% using the Discrete Shearlet Transform", Appl. Comput. Harmon. Anal. 25 pp.
% 25-46, (2008).
%
% Input:
%
% dst          - the nonsubsampled shearlet coefficients
%
% lpfilt       - the filter to be used for the Laplacian
%                Pyramid/ATrous decomposition using the codes
%                written by Arthur L. Cunha
%
% Output 
% 
% x         - the reconstructed image 
%
% Code contributors: Glenn R. Easley, Demetrio Labate, and Wang-Q Lim.
% Copyright 2011 by Glenn R. Easley. All Rights Reserved.
%

% Nlm=non_localmeansfilter(x_noisy,15,3,25);
input = imread('F:\dy_edge_ enhancement\nlm.png'); %����nlmȥ����ͼƬ
edge_canny = edge(input,'canny');  %��nlmȥ���ͼ����б�Ե���

level=length(dst)-1;
y{1}=dst{1};
for i=1:level,
      y{i+1} = real(sum(dst{i+1},3));
end
[L H]=size(y{3});
%a��������
a=1.5;
for i=1:L
    for j=1:H
       if(edge_canny(i,j) == 1)
           y{3}(i,j)=a*y{3}(i,j);
       end
    end
end

           
% y{1}=NLmeansfilter(y{1},10,2,18);
% y{2}=NLMceshi(y{2},1,5,10);
% y{3}=NLmeansfilter(y{3},10,2,20);
% y11 = zeros(size(y{1}));
% y1 = y;
% y1{2} = y11;
% y1{3} = y11;
% 
% y2 = y ;
% y2{1} = y11;
% y2{3} = y11;
% y3 = y;
% y3{1} = y11;
% y3{2} = y11;

% y1{1}=y{1};
% y2{1}=y{2};
% y3{1}=y{3};
% x{1}=real(atrousrec(y1,lpfilt));
% x{2}=real(atrousrec(y2,lpfilt));
% x{3}=real(atrousrec(y3,lpfilt));
 x=real(atrousrec(y,lpfilt));