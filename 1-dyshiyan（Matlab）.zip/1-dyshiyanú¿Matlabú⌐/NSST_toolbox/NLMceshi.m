function DenoisedImg=NLmeans(I,ds,Ds,h)
%I:������ͼ��
%ds:���򴰿ڰ뾶
%Ds:�������ڰ뾶
%h:��˹����ƽ������
%DenoisedImg��ȥ��ͼ��
I=double(I);
[m,n]=size(I);
DenoisedImg=zeros(m,n);
DenoisedImg1=zeros(m,n);
PaddedImg = padarray(I,[ds,ds],'symmetric','both');
DenoisedImg1=padarray(I,[ds,ds],'symmetric','both');
kernel=ones(2*ds+1,2*ds+1);
  
kernel=zeros(2*ds+1,2*ds+1);   
for d=1:ds    
  value= 1 / (2*d+1)^2 ;    
  for i=-d:d
  for j=-d:d
    kernel(ds+1-i,ds+1-j)= kernel(ds+1-i,ds+1-j) + value ;
  end
  end
end
kernel = kernel./ ds;
%kernel=[0.1070 0.1131 0.1070
        %0.1131 0.1196 0.1131
        %0.1070 0.1131 0.1070]
    %kernel=[0.1019 0.1154 0.1019
        %0.1154 0.1308 0.1154
       % 0.1019 0.1154 0.1019]
    
h2=h*h;
%kernel=ones(2*ds+1,2*ds+1);
%kernel=kernel./((2*ds+1)*(2*ds+1));
for i=1:m
    for j=1:n
        i1=i+ds;
        j1=j+ds;
        W1=PaddedImg(i1-ds:i1+ds,j1-ds:j1+ds);
        DenoisedImg1(i1,j1)=sum(sum(kernel.*W1));
 
    end
end
                

for i=1:m
    for j=1:n
        i1=i+ds;
        j1=j+ds;
       % W1=PaddedImg(i1-ds:i1+ds,j1-ds:j1+ds);%���򴰿�1
        wmax=0;
        average=0;
        sweight=0;
        %%��������
        rmin = max(i1-Ds,ds+1);
        rmax = min(i1+Ds,m+ds);
        smin = max(j1-Ds,ds+1);
        smax = min(j1+Ds,n+ds);
        for r=rmin:rmax
            for s=smin:smax
                if(r==i1&&s==j1)
                continue;
                end
                %W2=PaddedImg(r-ds:r+ds,s-ds:s+ds);%���򴰿�2
                %Dist2=sum(sum(kernel.*(W1-W2).*(W1-W2)));%��������
              Dist2=abs((DenoisedImg1(i1,j1)-DenoisedImg1(r,s))*(DenoisedImg1(i1,j1)-DenoisedImg1(r,s)));
                  %Dist2=abs(DenoisedImg1(i1,j1)-DenoisedImg1(r-ds,s-ds));
                   %Dist2=abs(DenoisedImg1(i1,j1)^2+DenoisedImg1(r-ds,s-ds)^2-2*DenoisedImg1(i1,j1)*DenoisedImg1(r-ds,s-ds));
                w=exp(-Dist2/h2);
                if(w>wmax)
                    wmax=w;
                end
                sweight=sweight+w;
                average=average+w*PaddedImg(r,s);
            end
        end
        average=average+wmax*PaddedImg(i1,j1);%����ȡ���Ȩֵ
        sweight=sweight+wmax;
        DenoisedImg(i,j)=average/sweight;
        %if sweight > 0
             %DenoisedImg(i,j) = average / sweight;
         %else
            % DenoisedImg(i,j) = I(i,j);
        end                
    end
end