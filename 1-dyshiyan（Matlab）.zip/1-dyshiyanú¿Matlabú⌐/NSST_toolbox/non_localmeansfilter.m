function [output]=non_localmeansfilter(P,searchwindow,similarwindow,h)
% h=sigma
% P=input picture
% parameters initialization
h=h*h;
f=similarwindow;
t=searchwindow;
%output matrix initialization
[m,n]=size(P);
output=zeros(m,n);
%fill the input matrix
%calculate the weight in the new matrix Q
Q=padarray(P,[f f],'symmetric');
%calculate the kernel according the distance 
kernel1=kernel(f);
for i=1:m
    for j=1:n
        %the center of the matrix of my similarwindow is(i1,j1)
        %the size of the matrix of my similarwindow is (2f+1) X (2f+1)
        i1=f+i;
        j1=f+j;
        M1=Q(i1-f:i1+f,j1-f:j1+f);
        %the coefficient of the weight is parameter is weight
        weightmax=0;
        sumweight=0;
        w1=0;
        %define the searchwindow ,the size of my searchwindow is not sure
        %the minisize of the searchwindow is t X t
        trowmin=max(i1-t,f+1);
        trowmax=min(i1+t,m+f);
        tclomin=max(j1-t,f+1);
        tclomax=min(j1+t,n+f);
        for trow=trowmin:1:trowmax
            for tcol=tclomin:1:tclomax
                %when calculate the (trow,tcol)=(i1,j1),jump
                %the coefficient of itself is the max of all of the
                %coefficient
                if(trow==i1 && tcol==j1)
                    continue;
                end
                M2=Q(trow-f:trow+f,tcol-f:tcol+f);
                w=sum(sum(kernel1.*(M2-M1).*(M2-M1)));
                %calculate the w(i,j)
                weight=exp(-w/h);
                sumweight=sumweight+weight;
                if weight>weightmax
                    weightmax=weight;
                end
                w1=w1+weight*Q(trow,tcol);
            end
        end
        sumweight=sumweight+weightmax;
        w1=weightmax*P(i,j)+w1;
        %average the weight
        output(i,j)=w1/sumweight;
    end
end
                
                
                
            
        