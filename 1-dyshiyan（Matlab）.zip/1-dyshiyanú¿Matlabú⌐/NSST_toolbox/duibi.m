input1=imread('yuantu/01.png');
[N,M]=size(input1);
input2=imread('�ü���/01.jpg');
input2=rgb2gray(input2);
input2=imresize(input2,[N,M]);
[MSE1, PSNR1] = Calc_MSE_PSNR(input1,input2);
K1=zeros(size(input1));
for(i=1:M)
    for(j=1:N)
        K1(j,i)=input1(j,i)-input2(j,i);
    end
end
imshow(K1,[]);
