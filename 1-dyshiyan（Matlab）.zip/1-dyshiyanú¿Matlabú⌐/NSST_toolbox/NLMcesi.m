x=double(imread('lena.pgm'));
[L L]=size(x);

% ����
sigma=20;
x_noisy=x+sigma.*randn(L,L);
nlm=NLmeansfilter(x_noisy,5,20,15);

zdd1=max(max(x));
zdd2=min(min(x));
yy=zdd(nlm,zdd2,zdd1);
psnr1=psnr(yy,x,zdd1);

figure(3)
imagesc(nlm)
colormap('gray')
axis off
axis image