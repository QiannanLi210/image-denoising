function xm=zdd( x, mn, mx )
x = x - min( x(:) );
x = x ./ max(x(:));
xm= mn + x * (mx-mn);
end