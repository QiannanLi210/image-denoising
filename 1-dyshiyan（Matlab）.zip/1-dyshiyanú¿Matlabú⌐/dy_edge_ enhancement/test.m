clc;
clear;
M=double(imread('lena.png'));
[L L]=size(M);

% ����
sigma=25;
N=M+sigma.*randn(L,L);
img = edge(N,'canny',0.29); 
K1=non_localmeansfilter(N,3,9,20);


[MSE, PSNR] = Calc_MSE_PSNR(M,K1);  %Mԭͼ��K1����֮���ͼ
K = [0.01 0.03];
window = fspecial('gaussian', 11, 1.5);
L = 255;
SSIM1=ssim(M,K1,K,window,L);  %K��Window��Lͨ��
% imwrite( uint8(K1),'gvhg.png');
% 
figure(1)
imshow(img)
colormap('gray')
title('the orign image');
axis off;

figure(2)
imagesc(N)
colormap('gray')
title('the noise image');
axis off;

figure(3)
imagesc(K1)
colormap('gray')
title('denoising');
axis off;