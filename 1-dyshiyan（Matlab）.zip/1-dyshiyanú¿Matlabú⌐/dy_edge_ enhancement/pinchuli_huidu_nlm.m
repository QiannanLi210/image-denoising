clear all
clc;
% ����������ͼ��nlmȥ��

inputfile='F:\����25_SR_DataSet�Ҷ�ͼ\'; 
% outputfile_b='C:\Users\asus\Desktop\image_b\'; 
ountputfile_result='F:\nlmȥ��25_SR_DataSet�Ҷ�ͼ\';
% test='C:\Users\asus\Desktop\img_2\';
Files=dir([inputfile '*.png']); 
number=length(Files); 
% message = imread('number_3.bmp');

% imb = imread('num.bmp');
for i=1:number
    in=imread([inputfile Files(i).name]);
   
%     imwrite(yuantu,'yuantu.bmp','bmp');
%     imwrite(input,[outputfile_b Files(i).name(1:end-4) 'b.bmp']);
    
    input=double(in)+25*randn(size(in)); 
%     input1 = input( :,: ,1);
%     input2 = input( :,: ,2);
%     input3 = input( :,: ,3);
    nlm=non_localmeansfilter(input,15,3,25);

%     r1=non_localmeansfilter(input1,1,9,20);
%     r2=non_localmeansfilter(input2,1,9,20);
%     r3=non_localmeansfilter(input3,1,9,20);
%     result= zeros(size(input));
%     result(:,:,1) = r1;
%     result(:,:,2) = r2;
%     result(:,:,3) = r3;


    
    imwrite( uint8(nlm),[ountputfile_result Files(i).name]); 
end
  