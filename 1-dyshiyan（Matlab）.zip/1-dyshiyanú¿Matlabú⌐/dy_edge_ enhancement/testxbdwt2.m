close all;clear all;clc;
a=imread('lena.png');
% sigma=5;
% f_imnoise=double(a)+sigma*randn(size(a));
% x=rgb2gray(a);  % С���任���ɻҶ�ͼ
[cA,cH,cV,cD]=dwt2(a,'haar');  %��ͼ����С���ֽ�
figure,
subplot(2,2,1);
mi=min(min(cA));
ma=max(max(cA));
cA1=(cA-mi)*255/(ma-mi);
cA1=uint8(cA1);
imshow(cA1);
title('����ϵ��A1');
imwrite( uint8(cA1),'resultA1/yijicA.png');

subplot(2,2,2);
mi=min(min(cH));
ma=max(max(cH));
cH1=(cH-mi)*255/(ma-mi);
cH1=uint8(cH1);
imshow(cH1);
title('ˮƽϸ�ڷ���H1');
imwrite( uint8(cH1),'resultH1/yijicH.png');

subplot(2,2,3);
mi=min(min(cV));
ma=max(max(cV));
cV1=(cV-mi)*255/(ma-mi);
cV1=uint8(cV1);
imshow(cV1);
title('��ֱϸ�ڷ���V1');
imwrite( uint8(cV1),'resultV1/yijicV.png');

subplot(2,2,4);
mi=min(min(cD));
ma=max(max(cD));
cD1=(cV-mi)*255/(ma-mi);
cD1=uint8(cD1);
imshow(cD1);
title('�Խ�ϸ�ڷ���D1');
imwrite( uint8(cD1),'resultD1/yijicD.png');
x_idwt=idwt2(cA,cH,cV,cD,'haar');  %�ع���ͼ
figure,
% imshow(x_idwt,[]);
 imshow(uint8(x_idwt),[]);
% figure,
% imshow([cA,cH;cV,cD],[]);  %�ĸ������ϳ�ͼƬ