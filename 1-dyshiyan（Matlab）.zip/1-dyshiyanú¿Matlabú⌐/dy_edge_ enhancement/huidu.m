% inputimg = double(imread('F:\dy_edge_ enhancement\image\lena.png'));
inputimg = double(imread('05.png'));
% inputimg = double(imread('F:\xiaoboshiyanshuju\ԭͼ128\11.png'));
sigma=25;  %����
input1=inputimg+sigma*randn(size(inputimg)); 
% inputimg1 = inputimgnoise(:,:,1);
% inputimg2 = inputimgnoise(:,:,2);
% inputimg3 = inputimgnoise(:,:,3);
% %  img1 = edge(input1,'canny',0.29); 
% img2 = edge(inputimg2,'canny',0.21); 
% img3 = edge(inputimg3,'canny',0.21); 
nlm_1=non_localmeansfilter(input1,9,3,25); %��ǰ�ߴ󣬺��С��hԽС������Խ�ࣻhԽ������ԽС��ȥ��������ƽ��
% nlm_2=non_localmeansfilter(inputimg2,1,9,20);
% nlm_3=non_localmeansfilter(inputimg3,1,9,20);
% % by= zeros(size(inputimg));
%  by_1 = by(:,:,1) ;
%  by_2 = by(:,:,2) ;
%  by_3 = by(:,:,3) ;
% % [M,N] = size(input1);
% %     for j1=1:M
% %         for k1=1:N
% %             if(img(j1,k1)==1)
% %                 by(j1,k1)=input1(j1,k1);
% %             end
% %         end
% %     end
%      for j2=1:M
%         for k2=1:N
%             if(img2(j2,k2)==1)
%                 by_2(j2,k2)=inputimg2(j2,k2);
%             end
%         end
%     end
%     for j3=1:M
%         for k3=1:N
%             if(img3(j3,k3)==1)
%                 by_3(j3,k3)=inputimg3(j3,k3);
%             end
%         end
%     end
%       by(:,:,1)= by_1;
%      by(:,:,2)= by_2;
%      by(:,:,3)= by_3;
     
% %       nlmth= nlm_1;
%      nlm(:,:,1)= nlm_1;
%      nlm(:,:,2)= nlm_2;
%      nlm(:,:,3)= nlm_3;
     
    
%    th_1 = nlm(:,:,1) ;
%  th_2 = nlm(:,:,2) ;
%  th_3 = nlm(:,:,3) ;
     
% %     for j11=1:M
% %         for k11=1:N
% %             if(img(j11,k11)==1)
% %                 nlmth(j11,k11)=input1(j11,k11);
% %             end
% %         end
% %     end
%      for j22=1:M
%         for k22=1:N
%             if(img2(j22,k22)==1)
%                 th_2(j22,k22)=inputimg2(j22,k22)+nlm_2(j22,k22);
%             end
%         end
%     end
%     for j33=1:M
%         for k33=1:N
%             if(img3(j33,k33)==1)
%                 th_3(j33,k33)=inputimg3(j33,k33)+nlm_3(j33,k33);
%             end
%         end
%     end
%       th= zeros(size(inputimg));
%      th(:,:,1)= th_1;
%      th(:,:,2)= th_2;
%      th(:,:,3)= th_3;
     
     subplot(1,3,1);
     imshow(uint8(inputimg));
     title('ԭͼ');
     subplot(1,3,2);
     imshow(uint8(input1));
      title('����ͼ');
     subplot(1,3,3);
     imshow(uint8(nlm_1));
      title('nlmȥ��ͼ');
      imwrite(uint8(nlm_1),'nlm.png');   %nlmȥ��֮���ͼ
%      imwrite(uint8(nlmth),'nlmth.png');//��Ե�滻
%      imwrite(uint8(by),'by.png');//��Եͼ
[MSE, PSNR] = Calc_MSE_PSNR(inputimg,nlm_1);
K = [0.01 0.03];
window = fspecial('gaussian', 11, 1.5);
L = 255;
SSIM1=ssim(inputimg,nlm_1,K,window,L);  %K��Window��Lͨ��
% figure(1)
% imshow(img1);
% figure(2)
% imshow(img2);
% figure(3)
% imshow(img3);