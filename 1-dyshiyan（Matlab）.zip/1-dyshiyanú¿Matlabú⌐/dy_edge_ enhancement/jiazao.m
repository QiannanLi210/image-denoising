clear all;
clc;

f_original=imread('F:\dy_edge_ enhancement\image\house.png');
sigma=25;
f_imnoise=double(f_original)+sigma*randn(size(f_original));  %����
imwrite(uint8(f_imnoise),'jiazao10.png');
subplot(1,2,1)
imshow(uint8(f_original));
title('ԭͼ');
subplot(1,2,2)
imshow(uint8(f_imnoise));
title('����ͼ');
