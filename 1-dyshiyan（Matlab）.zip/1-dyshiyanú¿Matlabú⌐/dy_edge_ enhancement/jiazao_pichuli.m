clear all;
clc;
inputfile='G:\dyshiyan\testsets\'; 
ountputfile_result='G:\dyshiyan\55\testjiazaoyuantu55\';
Files=dir([inputfile '*.png']); 
number=length(Files); 
for i=1:number
    in=imread([inputfile Files(i).name]);
 sigma=55;
 f_imnoise=double(in)+sigma*randn(size(in));  %����
% imwrite( uint8(f_imnoise),[ountputfile_result Files(i).name]); 
% imshow(uint8(f_imnoise),'jzlenna.png');
 imwrite(uint8(f_imnoise),[ountputfile_result Files(i).name(1:end-4) '.png']); %ͼƬ����ԭ��������+denoise.png
end