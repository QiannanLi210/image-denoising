clc;
clear all;
B = imread('08.png');
A = imread('501.5.png');
s=imsubtract(B,A);
imshow(s);
imwrite(s,'chazhi501.5.png')