from network import *
from PIL import Image
import scipy.misc as misc
import os
from config import *
from skimage.measure import compare_psnr as psnr
from skimage.measure import compare_ssim as ssim
class DnCNN:
    def __init__(self):
        self.clean_img = tf.placeholder(tf.float32, [None, None, None, IMG_C])
        self.noised_img = tf.placeholder(tf.float32, [None, None, None, IMG_C])
        self.train_phase = tf.placeholder(tf.bool)
        dncnn = net("DnCNN")
        self.res = dncnn(self.noised_img, self.train_phase)
        self.denoised_img = self.noised_img - self.res
        self.loss = tf.reduce_mean(tf.reduce_sum(tf.square(self.res - (self.noised_img - self.clean_img)), [1, 2, 3]))
        self.Opt = tf.train.AdamOptimizer(1e-3).minimize(self.loss)
        self.sess = tf.Session()
        self.sess.run(tf.global_variables_initializer())

    def train(self):
        clean_filepath = "F:/dyshiyan/dnSRset128//"
        clean_filenames = os.listdir(clean_filepath)
        noise_filepath = "F:/dyshiyan/15/yuantujiazao15//"
        noise_filenames = os.listdir(noise_filepath)
        saver = tf.train.Saver()
        # saver.restore(self.sess, "./sava_para885-25-1.5/DnCNN.ckpt")
        for epoch in range(50):
            for i in range(clean_filenames.__len__() // BATCH_SIZE):
                cleaned_batch = np.zeros([BATCH_SIZE, IMG_H, IMG_W, IMG_C])
                noised_batch = np.zeros([BATCH_SIZE, IMG_H, IMG_W, IMG_C])
                for idx, filename in enumerate(clean_filenames[i * BATCH_SIZE:i * BATCH_SIZE + BATCH_SIZE]):
                    cleaned_batch[idx, :, :, 0] = np.array(Image.open(clean_filepath + filename))

                for idx, filename1 in enumerate(noise_filenames[i * BATCH_SIZE:i * BATCH_SIZE + BATCH_SIZE]):
                # noised_batch = cleaned_batch + np.random.normal(0, SIGMA, cleaned_batch.shape)
                    noised_batch[idx, :, :, 0] = np.array(Image.open(noise_filepath + filename1))

                self.sess.run(self.Opt, feed_dict={self.clean_img: cleaned_batch, self.noised_img: noised_batch, self.train_phase: True})
                if i % 10 == 0:
                    [loss, denoised_img] = self.sess.run([self.loss, self.denoised_img], feed_dict={self.clean_img: cleaned_batch, self.noised_img: noised_batch, self.train_phase: False})
                    print("Epoch: %d, Step: %d, Loss: %g"%(epoch, i , loss))
                    compared = np.concatenate((cleaned_batch[0, :, :, 0], noised_batch[0, :, :, 0], denoised_img[0, :, :, 0]), 1)
                    Image.fromarray(np.uint8(compared)).save("./TrainingResults1//"+str(epoch)+"_"+str(i)+".png")
                if i % 100 == 0:
                    saver.save(self.sess, "./sava_para-wubianyuan50-15-1.5//DnCNN.ckpt")
            # np.random.shuffle([clean_filenames])    #防止模型抖动，打乱顺序
            # np.random.shuffle(noise_filenames)


    def test(self):
        saver = tf.train.Saver()
        psnrnum = 0
        ssimnum = 0
        saver.restore(self.sess, "./sava_para50-25-1.5/DnCNN.ckpt")
        # X = os.listdir('F:/dyshiyan/testsetsSingnal//')
        X = os.listdir('F:/dyshiyan/testsets//')
        # Z = os.listdir('F:/dyshiyan/testsetsSingnalzqbianyuan50-2.0//')
        Z = os.listdir('F:/dyshiyan/testsetsjiazao25//')
        for i in range(Z.__len__()):
            # x = np.array(Image.open('F:/dyshiyan/testsetsSingnal//' + X[i]))[np.newaxis, :, :,np.newaxis]
            # z = np.array(Image.open('F:/dyshiyan/testsetsSingnalzqbianyuan50-2.0//' + Z[i]))[np.newaxis, :, :,np.newaxis]
            x = np.array(Image.open('F:/dyshiyan/testsets//' + X[i]))[np.newaxis, :, :, np.newaxis]
            z = np.array(Image.open('F:/dyshiyan/testsetsjiazao25//' + Z[i]))[np.newaxis, :, :,np.newaxis]
            [denoised_img] = self.sess.run([self.denoised_img], feed_dict={self.clean_img: x, self.noised_img: z,self.train_phase: True})

            psnrnum += psnr(np.uint8(x[0, :, :, 0]), np.uint8(denoised_img[0, :, :, 0]))
            ssimnum += ssim(np.uint8(x[0, :, :, 0]), np.uint8(denoised_img[0, :, :, 0]))

            image1 = np.concatenate((z[0, :, :, 0], denoised_img[0, :, :, 0]), axis=1)
            #Image.fromarray(np.uint8(image1)).save("F:/dyshiyan/testresultsyuantu50-2.0bianyuanSingle//" + str(Z[i]))
            # Image.fromarray(np.uint8(denoised_img[0, :, :, 0])).save("F:/dyshiyan/testwubianyuanresultssingle//"+str(Z[i]))
            # Image.fromarray(np.uint8(denoised_img[0, :, :, 0])).save("F:/dyshiyan/dy_dncnncancharesults/testdangetu//" + str(Z[i]))
            Image.fromarray(np.uint8(denoised_img[0, :, :, 0])).save("F:/dyshiyan/canchatestresults25-1.5//" + str(Z[i]))
        PSNR0 = psnrnum/8
        SSIM0 = ssimnum/8
        # PSNR0 = psnrnum / 1
        # SSIM0 = ssimnum/1
        print(PSNR0)
        print(SSIM0)

    # def test(self, cleaned_path="C:/Users/Administrator/Desktop/test_yuan//lena.png",
    #          noised_path="C:/Users/Administrator/Desktop/test_jiazao//lena.png"):
    #     saver = tf.train.Saver()
    #     saver.restore(self.sess, "./save_para/DnCNN.ckpt")
    #     cleaned_img = np.reshape(np.array(misc.imresize(np.array(Image.open(cleaned_path)), [512, 512])), [1, 512, 512, 1])
    #     #noised_img = cleaned_img + np.random.normal(0, SIGMA, cleaned_img.shape)
    #     noised_img = np.reshape(np.array(misc.imresize(np.array(Image.open(noised_path)), [512, 512])),[1, 512, 512, 1])
    #     [denoised_img] = self.sess.run([self.denoised_img], feed_dict={self.clean_img: cleaned_img, self.noised_img: noised_img, self.train_phase: False})
    #     compared = np.concatenate((cleaned_img[0, :, :, 0], noised_img[0, :, :, 0], denoised_img[0, :, :, 0]), 1)
    #     Image.fromarray(np.uint8(compared)).show()
    #     #Image.fromarray(np.uint8(compared)).save("C:/Users/Administrator/Desktop/resultdncnn-tg1111/1.png")

if __name__ == "__main__":
    dncnn = DnCNN()
    dncnn.test()

