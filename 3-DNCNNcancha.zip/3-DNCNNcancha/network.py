from ops import *
from config import *
import numpy as np

class net:
    def __init__(self, name):
        self.name = name

    # def __call__(self, inputs, train_phase):
    #     with tf.variable_scope(self.name):
    #         inputs = tf.nn.relu(conv("conv0", inputs, 64, 3, 1))
    #         for d in np.arange(1, DEPTH - 1):
    #             inputs = tf.nn.relu(batchnorm(conv("conv_" + str(d + 1), inputs, 64, 3, 1), train_phase, "bn" + str(d)))
    #         inputs = conv("conv" + str(DEPTH - 1), inputs, IMG_C, 3, 1)
    #         return inputs

    def __call__(self, inputs, train_phase):
        with tf.variable_scope(self.name):
            inputs1 = tf.nn.relu(conv("conv1", inputs, 64, 3, 1))
            #for d in np.arange(1, DEPTH - 1):
            #inputs = tf.nn.relu(batchnorm(conv("conv_" + str(d + 1), inputs, 64, 3, 1), train_phase, "bn" + str(d)))
            inputs2 = tf.nn.relu(batchnorm(conv("conv2", inputs1, 64, 3, 1), train_phase, "bn" ))
            inputs3 = tf.nn.relu(batchnorm(conv("conv3", inputs2, 64, 3, 1), train_phase, "bn"))
            inputs4 = tf.nn.relu(batchnorm(conv("conv4", inputs3, 64, 3, 1), train_phase, "bn"))
            temp = tf.concat([inputs1, inputs4],axis=3)
            inputs5 = tf.nn.relu(batchnorm(conv("conv5", inputs4, 64, 3, 1), train_phase, "bn"))
            inputs6 = tf.nn.relu(batchnorm(conv("conv6", inputs5, 64, 3, 1), train_phase, "bn"))
            inputs7 = tf.nn.relu(batchnorm(conv("conv7", inputs6, 64, 3, 1), train_phase, "bn"))
            temp = tf.concat([temp, inputs7],axis=3)
            inputs8 = tf.nn.relu(batchnorm(conv("conv8", inputs7, 64, 3, 1), train_phase, "bn"))
            inputs9 = tf.nn.relu(batchnorm(conv("conv9", inputs8, 64, 3, 1), train_phase, "bn"))
            inputs10 = tf.nn.relu(batchnorm(conv("conv10", inputs9, 64, 3, 1), train_phase, "bn"))
            temp = tf.concat([temp, inputs10],axis=3)
            inputs11 = tf.nn.relu(batchnorm(conv("conv11", inputs10, 64, 3, 1), train_phase, "bn"))
            inputs12 = tf.nn.relu(batchnorm(conv("conv12", inputs11, 64, 3, 1), train_phase, "bn"))
            inputs13 = tf.nn.relu(batchnorm(conv("conv13", inputs12, 64, 3, 1), train_phase, "bn"))
            temp = tf.concat([temp, inputs13],axis=3)
            inputs14 = tf.nn.relu(batchnorm(conv("conv14", inputs13, 64, 3, 1), train_phase, "bn"))
            inputs15 = tf.nn.relu(batchnorm(conv("conv15", inputs14, 64, 3, 1), train_phase, "bn"))
            inputs16 = tf.nn.relu(batchnorm(conv("conv16", inputs15, 64, 3, 1), train_phase, "bn"))
            # temp = tf.concat([temp, inputs16],axis=3)
            # inputs17 = tf.nn.relu(batchnorm(conv("conv17", inputs16, 64, 3, 1), train_phase, "bn"))
            # inputs18 = tf.nn.relu(batchnorm(conv("conv18", inputs17, 64, 3, 1), train_phase, "bn"))
            # inputs19 = tf.nn.relu(batchnorm(conv("conv19", inputs18, 64, 3, 1), train_phase, "bn"))
            # temp = tf.concat([temp, inputs19], axis=3)
            inputs17 = conv("conv17" , tf.concat([temp, inputs16],axis=3), IMG_C, 3, 1)
            return inputs17